#include "AgendaUI.hpp"
#include "AgendaService.hpp"
#include "Date.hpp"
#include "User.hpp"
#include "Meeting.hpp"
#include "Storage.hpp"
#include <iostream>
#include <string>
using namespace std;

AgendaUI aui;

int main() {
    aui.OperationLoop();
    return 0;
}
