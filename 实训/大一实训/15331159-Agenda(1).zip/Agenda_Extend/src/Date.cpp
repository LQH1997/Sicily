#include "Date.hpp"
#include <sstream>
#include <string>
#include <iostream>
using namespace std;
Date::Date() {
  m_year = 0;
  m_month = 0;
  m_day = 0;
  m_hour = 0;
  m_minute = 0;
}
Date::Date(int t_year, int t_month, int t_day, int t_hour, int t_minute) {
    m_year = t_year;
    m_month = t_month;
    m_day = t_day;
    m_hour = t_hour;
    m_minute = t_minute;
}
Date::Date(std::string dateString) {
    int a,b,c,d,e;
    bool ifTrue = true;
    std::string f = dateString;
    //if(dateString.size() != 16) ifTrue = false;
    //if()
    a = (f[0]-'0')*1000 + (f[1]-'0')*100 +(f[2]-'0')*10 + (f[3]-'0');
    b = (f[5]-'0')*10 + (f[6]-'0');
    c = (f[8]-'0')*10 + (f[9]-'0');
    d= (f[11]-'0')*10 + (f[12]-'0');
    e = (f[14]-'0')*10 + (f[15]-'0');
    if(dateString.size() != 16) {ifTrue = false;}
    if(dateString[4] == '-' && dateString[7] == '-' && dateString[10] == '/' && dateString[13] == ':');
    else ifTrue = false;
    if(!ifTrue) {
        a =0; b= 0; c = 0; d = 0; e = 0;
    }
    m_year = a;
    m_month = b;
    m_day = c;
    m_hour = d;
    m_minute = e;
    
    //*this = temp;
}

int Date::getYear(void) const {
    return m_year;
}

void Date::setYear(const int t_year) {
    m_year = t_year;
}

int Date::getMonth(void) const {
    return m_month;
}

void Date::setMonth(const int t_month) {
    m_month = t_month;
}

int Date::getDay(void) const {
    return m_day;
}

void Date::setDay(const int t_day) {
    m_day = t_day;
}

int Date::getHour(void) const {
    return m_hour;
}

void Date::setHour(const int t_hour) {
    //if()
    m_hour = t_hour;
}

int Date::getMinute(void) const {
    return m_minute;
}

void Date::setMinute(const int t_minute) {
    m_minute = t_minute;
}

bool Date::isValid(const Date t_date) {
    int year = t_date.getYear();
    int month = t_date.getMonth();
    int day = t_date.getDay();
    int hour = t_date.getHour();
    int minute = t_date.getMinute();
    bool ifLeepYear;
    bool ifValid = true;
    if(year < 1000 || year >9999) return false;
    if(month <= 0 || month > 12) return false;
    if((year % 4 == 0 && year % 100 != 0)||(year % 400 == 0)) {
            ifLeepYear = true;
    } else {ifLeepYear = false;}

    if(month ==1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
        //cout<<month<<endl;
            if(day <= 0 || day > 31) return false;
        } else {
            if(month == 2) {
                if(ifLeepYear) {
                if(day <= 0 || day > 29) return  false;
             } else {
                if(day <= 0 || day > 28) return false;
             }
            } else {
                if(day <= 0 || day > 30) return  false;
            }
        }
        if(hour >= 24 || hour < 0 || minute >= 60 || minute < 0) return  false;
       return ifValid;
}

Date Date::stringToDate(const std::string t_dateString) {
    Date temp(0,0,0,0,0);
    bool ifTrue = true;
    if(t_dateString.size() != 16) {return temp; ifTrue = false;}
    if(t_dateString[4] == '-' && t_dateString[7] == '-' && t_dateString[10] == '/' && t_dateString[13] == ':');
    else {return temp; ifTrue = false;}
    for(int i =0; i < 16; i++) {
        if(i == 4 || i == 7 || i == 10 || i ==13) continue;
        if(t_dateString[i] >= '0' && t_dateString[i] <= '9');
        else ifTrue = false;
    }
    if(ifTrue) {
    std::string f;
    f = t_dateString;
    int a,b,c,d,e;
    a = (f[0]-'0')*1000 + (f[1]-'0')*100 +(f[2]-'0')*10 + (f[3]-'0');
    b = (f[5]-'0')*10 + (f[6]-'0');
    c = (f[8]-'0')*10 + (f[9]-'0');
    d = (f[11]-'0')*10 + (f[12]-'0');
    e = (f[14]-'0')*10 + (f[15]-'0');
    Date temp2(a,b,c,d,e);
    return temp2;
    }
    else return temp;
}

std::string Date::dateToString(Date t_date) { 
    if(Date::isValid(t_date)) {
    std::string c,z;
    std::stringstream b;
    int a = t_date.getYear();
    int q = t_date.getMonth();
    int w = t_date.getDay();
    int e = t_date.getHour();
    int r = t_date.getMinute();
    b<<a;
    b>>c;
    z = c;
    if(a == 0) 
    z += "000";
    b.clear();
    z += "-";
    b<<q;
    b>>c;
    if(q < 10) z += "0";
    z += c;
    b.clear();
    z += "-";
    b<<w;
    b>>c;
    if(w < 10) z += "0";
    z += c;  
    z+="/";
    b.clear();
    b<<e;
    b>>c;
    if(e < 10) z += "0";
    z += c;
    b.clear();
    z+=":";
    b<<r;
    b>>c;
    if(r < 10) z += "0";
    z += c;
    b.clear();
    return z;
  }
  else return "0000-00-00/00:00";
}

Date  &Date::operator =(const Date &t_date) {
    int year, month, day, hour, minute;
    year = t_date.getYear();
    month = t_date.getMonth();
    day = t_date.getDay();
    hour = t_date.getHour();
    minute = t_date.getMinute();
    this->setYear(year);
    this->setMonth(month);
    this->setDay(day);
    this->setHour(hour);
    this->setMinute(minute);
    return *this;
} 

bool Date::operator == (const Date &t_date) const {
    if(this->getYear() == t_date.getYear() && this->getMonth() == t_date.getMonth() && this->getDay() == t_date.getDay() && this->getHour() ==     t_date.getHour() && this->getMinute() == t_date.getMinute()) return true;
    else return false;
}

bool Date::operator > (const Date &t_date) const {
    if(*this == t_date) return false;
    if(this->getYear() > t_date.getYear()) return true;
    if(this->getYear() < t_date.getYear()) return false;
    if(this->getMonth() > t_date.getMonth()) return true;
    if(this->getMonth() < t_date.getMonth()) return false;
    if(this->getDay() > t_date.getDay()) return true;
    if(this->getDay() < t_date.getDay()) return false;
    if(this->getHour() > t_date.getHour()) return true;
    if(this->getHour() < t_date.getHour()) return false;
    if(this->getMinute() > t_date.getMinute()) return true;
    if(this->getMinute() < t_date.getMinute()) return false;
}

bool Date::operator<(const Date &t_date) const {
    if(!(*this == t_date) && !(*this > t_date)) return true;
    else return false;
}

bool Date::operator >= (const Date &t_date) const {
    if(!(*this < t_date)) return true;
    else return false;
}

bool Date::operator <= (const Date &t_date) const {
    if(!(*this > t_date)) return true;
    else false;
 }

