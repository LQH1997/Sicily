#include "Storage.hpp"
#include "User.hpp"
#include "Date.hpp"
#include "Meeting.hpp"
#include "Path.hpp"
#include <iostream>
#include <fstream>
#include <list>
#include <functional>
#include <memory>
#include <string>
using namespace std;

Storage::Storage() {
   readFromFile();
}

bool Storage::readFromFile(void) {
	ifstream readFile(Path::userPath,ios::in);
	if(!readFile.is_open()) return false;
	else {
    //cout<<"File opened"<<endl;
		while(!readFile.eof()) {
			string UserName, UserPassword, UserPhone, UserEmail;
			string all;
			getline(readFile,all);
      if(all.size() < 3 ) break;
      int count = 0;
      int count1 = 0;
      for(int i = 0; i < all.size(); i++) {
      if(all[i] == ',') continue;
      if(all[i] == '"' ) {
        count += 1;
        
      }
      if(count %2 == 0 ) {
        count1 += 1;
      }
      //cout<<count1<<endl;
      if(count1 == 0 && all[i] != '"') {
        UserName += all[i];
      }
      if(count1 ==1 && all[i] != '"') {
        UserPassword += all[i];
      }
      if(count1 ==2 && all[i] != '"') {
        UserEmail += all[i];
      }
      if(count1 ==3 && all[i] != '"') {
        UserPhone += all[i];
      }
    }
      //cout<<UserName<<UserPassword<<UserEmail<<UserPhone<<endl;
      User newUser(UserName,UserPassword,UserEmail,UserPhone);
      m_userList.push_back(newUser);
      //creatUser(newUser);
	}
  readFile.close();
}
  readFile.open(Path::meetingPath,ios::in);
  if(!readFile.is_open()) return false;
  else {
    std::vector<string> aabb;
    while(!readFile.eof()) {
      string a,b,c,d,e,f,g;
      string all;
      getline(readFile,all);
      if(all.size() <= 1 ) break;
      int arr[10];
      int count = 0;
      for(int i = 0; i < all.size(); i++) {
        if(all[i] == '"') {
        arr[count] = i;
        count += 1;
     }
 }
//string a,b,c,d,e;
a.assign(all,arr[0]+1,arr[1] -arr[0] -1);
b.assign(all,arr[2]+1,arr[3]- arr[2] -1);
c.assign(all,arr[4]+1,arr[5]- arr[4] -1);
d.assign(all,arr[6]+1,arr[7]- arr[6] -1);
e.assign(all,arr[8]+1,arr[9]- arr[8] -1);
aabb.clear();
string r;
for(int www = 0; www < b.size(); www++) {
  if(b[www] != '&') r += b[www];
  else {
    aabb.push_back(r);
    r = "";
  }
}
aabb.push_back(r);
//cout<<"all"<<all<<endl;
//cout<<a<<endl<<b<<endl<<c<<endl<<d<<endl<<e<<endl;
   // std::vector<string> aabb;
    //int _count = 0;
    //for(int w = 0; w < b.size(); w++) {
    //  if(b[w] == '&') _count += 1;
    //}
     //string t;
     //t = "";
    //for(int e = 0; e < b.size(); e++) {
     //   if(b[e] != '&') t += b[e];
        //else {
    //t = b;
          //aabb.push_back(t); t ="";
          //}
   // }
   // aabb.push_back(b);
   Date temp1(c), temp2(d);
    //cout<<a<<" "<<b<<" "<<c<<" "<< d <<" "<< f <<endl;
    Meeting newMeet(a,aabb,temp1,temp2,e);
   m_meetingList.push_back(newMeet);
   // }
  }
  return true;
}
}

bool Storage::writeToFile(void) {
    ofstream writeFile;
    writeFile.open(Path::userPath,ios::out | ios::trunc);
    if(!writeFile.is_open()) return false;
    else {
          for(auto i = m_userList.begin(); i != m_userList.end(); i++) {
            //i++;
              writeFile <<'"'<< i -> getName()<<'"'<<','
              <<'"'<<i -> getPassword()<<'"'<<','<<'"'<<i -> getEmail()<<'"'<<','<<'"'
              <<i -> getPhone()<<'"'<<endl;
             // cout <<'"'<< i -> getName()<<'"'<<','
             // <<'"'<<i -> getPassword()<<'"'<<','<<'"'<<i -> getEmail()<<'"'<<','<<'"'
              //<<i -> getPhone()<<'"'<<endl;
          }
    }
    writeFile.close();
    writeFile.open(Path::meetingPath,ios::out | ios::trunc);
    if(!writeFile.is_open()) return false;
    else {
        for(auto i = m_meetingList.begin(); i != m_meetingList.end();i++) {
          writeFile <<'"'<<i->getSponsor()<<'"'<<','<<'"';
          std::vector<string> abc = i -> getParticipator();
          for(int q = 0; q < abc.size() - 1; q++) {
            writeFile << abc[q] <<'&';
          }
           writeFile << abc[abc.size()-1] <<'"' <<',';
           writeFile << '"' << Date::dateToString( i -> getStartDate())<<'"'<<','<<'"'
                     <<  Date::dateToString ( i -> getEndDate())<<'"'<<','<<'"' << i -> getTitle()<<'"'<<endl;
        }
    }
}

std::shared_ptr<Storage> Storage::getInstance(void) {
    if (!m_instance.get()) m_instance.reset(new Storage());
    return m_instance;
    //shared_ptr<Storage> ps(new Storage());
    //return ps;
}

Storage::~Storage() {
       writeToFile();
}

void Storage::createUser(const User & t_user) {
     //cout<<"in creatUser"<<endl;
     m_instance = Storage::getInstance();
     m_instance-> m_userList.push_back(t_user);
     m_dirty = true;
}

std::list<User> Storage::queryUser(std::function<bool(const User &)> filter) const {
            list<User> temp;
            for(auto i = m_instance->m_userList.begin(); i != m_instance->m_userList.end(); i++) {
              if(filter(*i)) {
                temp.push_back(*i);
              }
            }
           return temp; 
}

int Storage::updateUser(std::function<bool(const User &)> filter,
                 std::function<void(User &)> switcher) {
     int count = 0;
     for(auto i =  m_instance->m_userList.begin(); i != m_instance->m_userList.end(); i++) {
      if(filter(*i)) {
        switcher(*i);
        count++;
      }
     }
     m_dirty = true;
     return count;

}
int Storage::deleteUser(std::function<bool(const User &)> filter) {
                  int count = 0;
                  for(auto i = m_instance->m_userList.begin(); i != m_instance->m_userList.end();) {
                    if(filter(*i)) {
                      auto t = i;
                      i++;
                     m_instance->m_userList.erase(t);
                      count++;
                    } else i++;
                  }
                  m_dirty = true;
                return count;
}

void Storage::createMeeting(const Meeting & t_meeting) {
  //cout<<"2"<<endl;
           m_instance->m_meetingList.push_back(t_meeting);
           m_dirty = true;
}

std::list<Meeting> Storage::queryMeeting(std::function<bool(const Meeting &)> filter) const {
    std::list<Meeting> temp;
    for(auto i = m_instance->m_meetingList.begin(); i != m_instance->m_meetingList.end(); i++) {
      if(filter(*i)) {
        temp.push_back(*i);
      }
    }
    return temp;
}

int Storage::updateMeeting(std::function<bool(const Meeting &)> filter,
                    std::function<void(Meeting &)> switcher) {
     int count = 0;
     for(auto  i = m_instance->m_meetingList.begin(); i != m_instance->m_meetingList.end(); i++) {
      if(filter(*i)) {
        switcher(*i);
        count++;
      }
     }
     m_dirty = true;
     return count;
}

int Storage::deleteMeeting(std::function<bool(const Meeting &)> filter) {
        int  count = 0;
        int _count = 0;
        for(auto i = m_instance->m_meetingList.begin(); i != m_instance->m_meetingList.end(); i++) {
          _count += 1;
        }
        for(int q = 0; q < _count; q++) {
        for(auto i = m_instance->m_meetingList.begin(); i != m_instance->m_meetingList.end(); i++) {
          //cout<<++_count<<endl;
          if(filter(*i)) {
            //cout<<"if filter"<<endl;
            auto t = i;
            //i = m_instance->m_meetingList.begin();
            m_instance->m_meetingList.erase(t);
            count++;
            break;
          };
        }
      }
        return count;
}

bool Storage::sync(void) {
    if(m_dirty) {
      writeToFile();
      m_dirty = false;
      return true;
    }  else return false;
}

shared_ptr<Storage> Storage::m_instance = nullptr;
