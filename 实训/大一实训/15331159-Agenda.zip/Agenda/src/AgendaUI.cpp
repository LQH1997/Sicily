#include "Date.hpp"
#include "User.hpp"
#include "Meeting.hpp"
#include "Storage.hpp"
#include "AgendaService.hpp"
#include "AgendaUI.hpp"
#include <iostream>
#include <string>
#include <cmath>

   using namespace std;

    AgendaUI::AgendaUI() {
           AgendaService m_agendaService();
}  

    void AgendaUI::OperationLoop(void) {
        startAgenda();
}

bool ifQuitAgenda = true;
    void AgendaUI::startAgenda(void) {
      bool ifExist = false;
      bool ifTrue = true;
      string op;
    while(ifQuitAgenda) {
      while(!ifExist) {
        //string op;
              for(int i = 0; i < 30; i++) cout<<"-";
                  cout<<"Agenda";
                  for(int q = 0; q < 30; q++) cout<<"-"; cout<<endl;
                  cout<<"Action :"<<endl;
                  cout<<"l    - log in Agenda by user name and password"<<endl;
                  cout<<"r    - register an Agenda account"<<endl;
                  cout<<"q    - quit Agenda"<<endl;
                  for(int z = 0; z < 66; z++) cout<<"-"; cout<<endl;
                op = AgendaUI::getOperation();
            ifExist = executeOperation(op);
        }
        if(op == "l") {userLogIn(); ifExist = false; continue;}
        if(op == "r") {userRegister(); ifExist = false; continue;}
        if(op == "q") {quitAgenda(); ifExist = false; continue;}
       // int count = 0;
       // count++;
       // if(count > 1) ifTrue = false;
              
       }
    }

    std::string AgendaUI::getOperation() {
         cout<<endl<<"Agenda : ~$  ";
           string cinOperation;
           cin>>cinOperation;
           return cinOperation;
}

    bool AgendaUI::executeOperation(std::string t_operation) {
         if(t_operation == "l" || t_operation == "r" || t_operation == "q") return true;
         else return false;
}
void printAction(string m_userName) {
              for(int i = 0; i < 30; i++) cout<<"-";
                  cout<<"Agenda";
                  for(int q = 0; q < 30; q++) cout<<"-"; cout<<endl;
                  cout<<"Action :"<<endl;
                  cout<<"o    - log out Agenda"<<endl;
                  cout<<"dc   - delete Agenda account"<<endl;
                  cout<<"lu   - list all Agenda users"<<endl;
                  cout<<"cm   - create a meeting"<<endl;
                  cout<<"la   - list all meetings"<<endl;
                  cout<<"las  - list all sponsor meetings"<<endl;
                  cout<<"lap  - list aa participate meetings"<<endl;
                  cout<<"qm   - query meeting by title"<<endl;
                  cout<<"qt   - query meeting by time interval"<<endl;
                  cout<<"dm   - delete meeting by title"<<endl;
                  cout<<"da   - delete all meetings"<<endl;
             for(int z = 0; z < 66; z++) cout<<"-"; cout<<endl<<endl;
             cout<<"Agenda@"<<m_userName<<" : # ";
}

    void AgendaUI::userLogIn(void) {
          cout<<"[log in] [user name] [password]"<<endl;
          cout<<"[log in] ";
          cin>> m_userName >> m_userPassword;
          //AgendaService agd;
          if(!m_agendaService.userLogIn(m_userName,m_userPassword)) cout<<"[error] "<<"fail!"<<endl;
          else {
            cout<<"[log in] "<< "succeed!" <<endl;
         string getOp;
         printAction(m_userName);
         while(cin>>getOp && getOp != "o") {

               if(getOp =="dc") {deleteUser();break;}
               if(getOp =="lu") {listAllUsers();printAction(m_userName);}
               if(getOp =="cm") {createMeeting();printAction(m_userName);}
               if(getOp =="la") {listAllMeetings();printAction(m_userName);}
               if(getOp =="las") {listAllSponsorMeetings();printAction(m_userName);}
               if(getOp =="lap") {listAllParticipateMeetings();printAction(m_userName);}
               if(getOp =="qm") {queryMeetingByTitle();printAction(m_userName);}
               if(getOp =="qt") {queryMeetingByTimeInterval();printAction(m_userName);}   
               if(getOp =="dm") {deleteMeetingByTitle();printAction(m_userName);}
               if(getOp =="da") {deleteAllMeetings();printAction(m_userName);}
               if(getOp != "dc" ||getOp != "lu" ||getOp != "cm" ||getOp != "la" ||getOp != "las" ||
                getOp != "qm" ||getOp != "qt" ||getOp != "dm" ||getOp != "da") cout<<"Agenda@"<<m_userName<<" : # ";

         }
          }
 }

    void AgendaUI::userRegister(void) {
         string a,b,c,d;
           cout<<"[register] [user name] [password] [email] [phone]"<<endl;
           cout<<"[register] ";
           cin>>a>>b>>c>>d;
          // AgendaService adg;
           if(a.size() > 15 || b.size() > 15 || c.size() > 15 || d.size() > 15)  cout<<"[error] fail!"<<endl;
           else 
           if(m_agendaService.userRegister(a,b,c,d)) {
            cout<<"[register] succeed!"<<endl; 
           } else cout<<"[error] fail!"<<endl;


}

    void AgendaUI::quitAgenda(void) {
           ifQuitAgenda = false;
}

    void AgendaUI::userLogOut(void) {
      
}

    void AgendaUI::deleteUser(void) {
      cout<<"[delete agenda account] succeed"<<endl;
      //AgendaService adg;
      m_agendaService.deleteUser(m_userName,m_userPassword);
}

    void AgendaUI::listAllUsers(void) {
       AgendaService adg;
       std::list<User> UL = adg.listAllUsers();
       cout<<"name           "<<"email          "<<"     phone          "<<endl;
       for(auto i = UL.begin(); i != UL.end(); i++) {
        cout<<i->getName();
        for(int q = 0; q < 15-(i->getName().size());q++) cout<<" ";
        cout<<i->getEmail(); 
        for(int q = 0; q < 20-(i->getEmail().size());q++) cout<<" ";
        cout<<i->getPhone();
        for(int q = 0; q < 15-(i->getPhone().size());q++) cout<<" "; cout<<endl;
       }
}

    void AgendaUI::createMeeting(void) {
        string parNumber;
        int _parNumber = 0;
        std::vector<string> PART; 
        string partis;
        string _title;
        string _date1;
        string _date2;
          cout<<"[create meeting] [the number of participators]"<<endl<<"[create meeting] ";
          cin>>parNumber;
          bool ifTrue = true;
          for(int p = 0 ; p < parNumber.size(); p++) {
            if(parNumber[p] < '0' || parNumber[p] > '9') {
              _parNumber = 0;
              ifTrue = false;
              //cout<<"sb"<<endl;
              break;
            }
          }
          if(ifTrue) {
            int op = parNumber.size();
            int count = 0;
            for(int r = op-1; r >= 0; r--, count++) {
                int var = (parNumber[r] - '0') * pow(10, count);
                _parNumber += var;
                //cout<<var<<endl;
            }
          }
          for(int wer = 0; wer < _parNumber; wer++) {
            cout<<"[create meeting] [please enter the participator "<<wer + 1<<" ]"<<endl;
            cout<<"[create meeting] ";
            cin>>partis;
            PART.push_back(partis);
          }
          cout<<"[create meeting] [title] [start time(yyyy-mm-dd/hh:mm)] [end time(yyyy-mm-dd:hh/mm)]"<<endl;
          cout<<"[create meeting] ";
          cin>>_title>>_date1>>_date2;
          //AgendaService agd;
          if(_title.size() > 15) cout<<"[error] fail!"<<endl;
          else
          if(m_agendaService.createMeeting(m_userName,_title,_date1,_date2,PART)) cout<<"[create meeting] succeed!"<<endl;
          else cout<<"[error] fail!"<<endl;
          
} 
    void coutMeetings(std::list<Meeting> meetList) {
           Date date1;
           cout<<"title          sponsor        start time        end time          participators"<<endl;
                      for(auto i = meetList.begin(); i != meetList.end(); i++) {
                cout<<i->getTitle();
                for(int z = 0 ; z < 15-(i->getTitle().size()); z++) cout<<" ";
                cout<<i->getSponsor();
                for(int z = 0; z < 15 - (i->getSponsor().size()); z++) cout<<" ";
                cout<<date1.dateToString(i->getStartDate())<<"  ";
                cout<<date1.dateToString(i->getEndDate())<<"  ";
                std::vector<string> STR = i -> getParticipator();
                for(int q = 0 ; q < STR.size(); q++) {
                  cout<<STR[q];
                  if(q == STR.size()-1) cout<<endl;
                  else cout<<",";
                }

           }
           cout<<endl;

}
    void AgendaUI::listAllMeetings(void) {
           std::list<Meeting> meetList;
          // AgendaService agd;
           meetList = m_agendaService.listAllMeetings(m_userName);
           coutMeetings(meetList);
}

    void AgendaUI::listAllSponsorMeetings(void) {
        std::list<Meeting> meetList;
        //AgendaService agd;
        meetList = m_agendaService.listAllSponsorMeetings(m_userName);
        coutMeetings(meetList);
}

    void AgendaUI::listAllParticipateMeetings(void) {
        std::list<Meeting> meetList;
        //AgendaService adg;
        meetList = m_agendaService.listAllParticipateMeetings(m_userName);
        coutMeetings(meetList);
}

    void AgendaUI::queryMeetingByTitle(void) {
        std::list<Meeting> meetList;
        string m_title;
        cout<<"[query meeting] [title]"<<endl;
        cout<<"[query meeting] ";
        cin>>m_title;
        //AgendaService adg;
        meetList = m_agendaService.meetingQuery(m_userName,m_title);
       // if(meetList.empty()) cout<<"No Meeting found"<<endl;
        //else {
          coutMeetings(meetList);
          //}
}

    void AgendaUI::queryMeetingByTimeInterval(void) {
         std::list<Meeting> meetList;
         string _date1, _date2;
         cout<<"[query meeting] [start time(yyyy-mm-dd/hh:mm)] [end time(yyyy-mm-dd/hh:mm)]"<<endl;
         cout<<"[query meeting] ";
         cin>>_date1>>_date2;
         //AgendaService adg;
         meetList = m_agendaService.meetingQuery(m_userName, _date1, _date2);
         coutMeetings(meetList);
;}

    void AgendaUI::deleteMeetingByTitle(void) {
     //AgendaService adg;
     string _title;
     cout<<"[delete meeting] [title]"<<endl;
     cout<<"[delete meeting] ";
     cin>>_title;
     bool c = m_agendaService.deleteMeeting(m_userName,_title);
     if(c) cout<<"[delete meeting] succeed!"<<endl << endl;
     else cout<<"[error] fail!"<<endl <<endl;
}
    void AgendaUI::deleteAllMeetings(void) {
      //AgendaService adg;
      bool c = m_agendaService.deleteAllMeetings(m_userName);
      if(c) cout<<"[delete meeting] succeed!"<<endl <<endl;
      else cout<<"[error] fail!"<<endl << endl;
}

    void AgendaUI::printMeetings(std::list<Meeting> t_meetings) {
       coutMeetings(t_meetings);
}






