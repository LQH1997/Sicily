#include "Date.hpp"
#include "Meeting.hpp"
#include "User.hpp"
#include "AgendaService.hpp"
#include "Storage.hpp"
#include <iostream>
#include <string>
#include <list>
using namespace std;

AgendaService::AgendaService() {
	shared_ptr<Storage> m_storage = Storage::getInstance();
}

AgendaService::~AgendaService() {

}

bool AgendaService::userLogIn(const std::string userName, const std::string password) {
  shared_ptr<Storage> m_storage = Storage::getInstance();
     std::list<User> a;
     a = m_storage -> queryUser([&] (const User &user) ->bool{bool b = (userName == user.getName() && password == user.getPassword()); return b;});
     if(a.empty()) return false;
     else return true;
}
	
bool AgendaService::userRegister(const std::string userName, const std::string password,
                      const std::string email, const std::string phone) {
  shared_ptr<Storage> m_storage = Storage::getInstance();
 	std::list<User> a = m_storage -> queryUser([&] (const User &user) -> bool{bool b = (userName == user.getName()); return b;});
 	if(a.empty()) {
 		User newUser(userName, password, email, phone);
    //cout<<"1"<<endl;
    //shared_ptr<Stroage> m_storage = Storage::getInstance();
    shared_ptr<Storage> manage = Storage::getInstance();
 		manage->createUser(newUser);
    //cout<<"2"<<endl;
 		return true;
 	}
 	else {
 		return false;
 	}
}

bool isParticipator(std::vector<std::string> Par) {
  bool ifTrue = true;
  for(int i = 0; i < Par.size(); i++) {
        shared_ptr<Storage> q = Storage::getInstance();
        std::list<User> w = q -> queryUser([&] (const User &user) -> bool {bool e = (Par[i] == user.getName()); return e;});
        if(w.empty()) {
          //cout<<Par[i]<<" is Not exist"<<endl;
              ifTrue = false;
              break;
        } //else cout<<Par[i]<<" exist"<<endl;
  }
  if(ifTrue) {
    //cout<<"is Par return true ";
    return true;
  } else {
    //cout<<"is Par return false ";
    return false;
  }
  return ifTrue;
 }

 bool ifInMeeting(vector<string> check, string userName) {
         bool ifTrue = false;
         for(int i = 0; i < check.size(); i++) {
          if(userName == check[i]) {
            ifTrue = true;
            break;
          }
         }
         return ifTrue;
 }

  bool AgendaService::deleteUser(const std::string userName, const std::string password) {
    shared_ptr<Storage> m_storage = Storage::getInstance();
     int a = m_storage -> Storage::deleteUser([&] (const User &user) -> bool{
      bool b = (userName == user.getName() && password == user.getPassword()); return b;
    });
     if(a == 0) return false;
     else {
       int count = m_storage->Storage::deleteMeeting([&] (const Meeting &meeting) -> bool{
        bool zz = (userName == meeting.getSponsor()); return zz;
      });
       int count2 = m_storage -> Storage::deleteMeeting([&] (const Meeting &meeting) -> bool {
        bool xx = (ifInMeeting(meeting.getParticipator(),userName));
        return xx;
       });
       return true;
     }
  }
  std::list<User> AgendaService::listAllUsers(void) const {
    shared_ptr<Storage> m_storage = Storage::getInstance();
      std::list<User> a = m_storage -> queryUser([&] (const User &user) {return true;});
      return a;
  }

bool ifTitle(string a) {
    bool ifTrue = false;
    shared_ptr<Storage> q = Storage::getInstance();
    list<Meeting> w = q -> queryMeeting([&] (const Meeting &meeting) -> bool {bool e = (a == meeting.getTitle()); return e;});
    if(w.empty()) {
      ifTrue = true;
    }
    if(ifTrue) {
      //cout<<"title return true "<<endl;
      return true;
    } else {
     // cout<<"title return false "<<endl;
      return false;
    }
}
  
 bool ifUser(string a) {
  bool ifTrue = true;
   shared_ptr<Storage> q = Storage::getInstance();
   //cout<<a<<" ";
   std::list<User> w = q -> queryUser([&] (const User &user) -> bool {bool e = ( a == user.getName()); return e;});
   if(w.empty()) {
    //cout<<"ifUser not exist"<<endl;
    ifTrue = false;
   } //else cout<<"user exist"<<endl;
   //return ifTrue;
   if(ifTrue) {
    //cout<<"is User return true ";
    return true;
   } else {
    cout<<"is User return false ";
    return false;
   }
 }
 
 bool ifDateValid(Date &date1, Date &date2) {
  if(date1 < date2) return true;
  else return false;
 }

bool checkDate(Date date1, Date date2, Date date3, Date date4) {
       bool a = (date1 >= date3 && date1 <= date4);
       bool b = (date2 >= date3 && date2 <= date4);
       bool c = (date1 <= date3 && date2 >= date4);
       return (a||b||c);
}
bool checkDate1(Date date1, Date date2, Date date3, Date date4) {
       bool a = (date1 > date3 && date1 < date4);
       bool b = (date2 > date3 && date2 < date4);
       bool c = (date1 < date3 && date2 > date4);
       return (a||b||c);
}

bool checkDate3(Date date1, Date date2, Date date3, Date date4) {
   return ((date1 >= date3 && date1 <= date4) || (date2 >= date3 && date2 <= date4) || (date1 <= date3 && date2 >= date4));
}

 bool isInPar(std::vector<string> parList, string userName) {
  bool ifTrue = false;
    for(auto i = parList.begin(); i != parList.end(); i++) {
      if(userName == *i) {
        ifTrue = true;
        break;
      }
    }
    return ifTrue;
 }

bool ifSponsorAvailabe(string userName, Date dt1, Date dt2) {
  shared_ptr<Storage> q = Storage::getInstance();
 
     std::list<Meeting> w = q -> queryMeeting([&] (const Meeting &meeting) -> bool {
       bool e = (userName == meeting.getSponsor() && checkDate1(dt1, dt2, meeting.getStartDate(), meeting.getEndDate()));
       return e;
     });
     if(w.empty()) return true;
     else return false;
 // if(mood == 2) {
 //      std::list<Meeting> w = queryMeeting([&] (const Meeting &meeting) -> {
 //      bool e = (userName == meeting.getSponsor() && checkDate(dt1, dt2, meeting.getStartDate(), meeting.getEndDate()));
 //      return e;
 //    });
  //}
}

bool ifParAvailble(std::vector<string> allPar, Date dt1, Date dt2) {
  bool ifTrue;
     shared_ptr<Storage> q = Storage::getInstance();
     std::list<Meeting> w = q -> queryMeeting([&] (const Meeting &meeting) -> bool {
      for(int r = 0; r < allPar.size(); r++) {
            bool e = (isInPar(meeting.getParticipator(),allPar[r]) && checkDate1(dt1, dt2, meeting.getStartDate(), meeting.getEndDate()));
            return e;
          }
     });
     if(w.empty()) return true;
     else return false;
}

bool ifVectorRepted(std::vector<string> v) {
  bool ifTrue = true;
    for(int i = 0; i < v.size() - 1; i++) {
      for(int q = i+1; q < v.size(); q++) {
        if(v[i] == v[q]) {
          ifTrue = false;
          break;
        }
      }
    }
    return ifTrue;
}

  bool AgendaService::createMeeting(const std::string userName, const std::string title,
                       const std::string startDate, const std::string endDate,
                       const std::vector<std::string> participator) {
    shared_ptr<Storage> m_storage = Storage::getInstance();
         Date date1(startDate), date2(endDate);
         bool _ifdate1 = Date::isValid(date1);
         bool _ifdate2 = Date::isValid(date2);
         if(participator.empty()) return false;
         for(int oo = 0; oo < participator.size(); oo++) {
              if(userName == participator[oo]) return false;
         }
         if(_ifdate1 == false || _ifdate2 == false) return false;
          bool ifPar = isParticipator(participator);  // CHECK IF VECTOR<STRING> ALL EXIST
          bool isUser = ifUser(userName);             // CHECK IF USER EXISTS
          bool isTitle = ifTitle(title);              // CHECK IF TITLE OCCUPIED
          bool ifDate = ifDateValid(date1,date2);     // CHECK IF DATE1 < DATE2
          bool ifVR = ifVectorRepted(participator);
          if(ifPar && isUser && isTitle && ifDate && ifVR) {
                   bool c = ifSponsorAvailabe(userName,date1,date2);
                   bool d = ifParAvailble(participator,date1,date2);
                   if(c && d) {
                    Meeting newMeeting(userName,participator,date1,date2,title);
                   m_storage -> createMeeting(newMeeting);
                   return true;
                 } else return false;
          }
          else return false;

  }

std::list<Meeting> AgendaService::meetingQuery(const std::string userName,
                                    const std::string title) const {
	std::list<Meeting> a = m_storage -> queryMeeting([&] (const Meeting &meeting) -> bool{bool c = (userName == meeting.getSponsor() && title == meeting.getTitle());return c;});
    return a;
}

std::list<Meeting> AgendaService::meetingQuery(const std::string userName,
                                    const std::string startDate,
                                    const std::string endDate) const {
   Date date1(startDate);
   //cout<<date1.dateToString(date1)<<endl;
   Date date2(endDate);
   //cout<<date2.dateToString(date2)<<endl;
    std::list<Meeting> a = m_storage -> queryMeeting([&] (const Meeting &meeting) -> bool { 
        bool b = (userName == meeting.getSponsor() || ifInMeeting(meeting.getParticipator(),userName)); 
    	   // bool c = ( (date1 >=  meeting.getStartDate() && date1 <= meeting.getEndDate())||
    		//(date2 >= meeting.getStartDate() && date2 <= meeting.getEndDate()) ||
        //(date1 <= meeting.getStartDate() && date2 >= meeting.getEndDate()));
   Date date3 = meeting.getStartDate(); Date date4 = meeting.getEndDate();
   bool c = checkDate3(date1,date2,date3,date4);
                  return (c && b);});
    return a;	    
}


 std::list<Meeting> AgendaService::listAllMeetings(const std::string userName) const{
      std::list<Meeting> a = m_storage -> queryMeeting([&] (const Meeting &meeting) -> bool{
        bool c = (userName == meeting.getSponsor());
        bool b = isInPar(meeting.getParticipator(), userName);
        return (c || b);
      });
      return a;
 }

 std::list<Meeting> AgendaService::listAllSponsorMeetings(const std::string userName) const {
       std::list<Meeting> a = m_storage -> queryMeeting([&] (const Meeting &meeting) -> bool {
       	bool b = (userName == meeting.getSponsor()); return b;
      });
       return a;
 }


  std::list<Meeting> AgendaService::listAllParticipateMeetings(
        const std::string userName) const  {
    //r//eturn m_storage -> queryMeeting([&] (Meeting &meeting) {return true;});
    //cout<<"in file"<<endl;
    std::list<Meeting> a;
     a = m_storage -> queryMeeting([&] (const Meeting &meeting) -> bool {
      bool b = isInPar(meeting.getParticipator(), userName);
           return b;
     });
    return a;
  }

 bool AgendaService::deleteMeeting(const std::string userName, const std::string title) {
      int  a = m_storage -> Storage::deleteMeeting([&] (const Meeting &meeting) -> bool {
      	bool b = (userName == meeting.getSponsor() && title == meeting.getTitle()); return b;
     });
      return (!(a == 0));
     
 	//return true;
 }

  bool AgendaService::deleteAllMeetings(const std::string userName) {
      int a = m_storage -> Storage::deleteMeeting([&] (const Meeting &meeting) -> bool {
      	bool b = (userName == meeting.getSponsor());
      	return b;
      });
      if(a == 0) return false;
      else return true;
    //return (!(a==0));
  //return true;
  }

void AgendaService::startAgenda(void) {
  shared_ptr<Storage> m_storage = Storage::getInstance();
  m_storage->sync();
}

  void AgendaService::  quitAgenda(void) {
   m_storage.reset();
  }
