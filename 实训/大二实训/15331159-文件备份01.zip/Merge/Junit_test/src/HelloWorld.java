import java.util.*;

public class HelloWorld {
	String str;
	public void main() {
		str = "Hello World!";
		System.out.println(str);
	}
	public String getStr() {
		return str;
	}
}